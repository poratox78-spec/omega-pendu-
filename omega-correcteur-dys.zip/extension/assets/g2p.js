// g2p du moteur OMEGA (_DECL2) — EXTRAIT VERBATIM de app/omega-pendu.html par build_assets.py, ne pas éditer.
var _DECL2 = (function () {
  // ---- PHON : briques AQUA-PHOTON v3 (distille, verbatim) ----
  const VOW='aeiouyàâäéèêëîïôöùûü'
  const NASAL=new Set(['an','am','en','em','in','im','yn','ym','on','om','un','um','ain','ein','oin','aim','ien'])
  const DBL=new Set(['rr','ll','mm','nn','tt','pp','ff','ss','cc','dd','bb','gg','zz'])
  const SEG=['eau','ill','ain','ein','oin','aim','ien','ou','au','eu','oi','ai','ei',
   'an','am','en','em','in','im','yn','ym','on','om','un','um',
   'ch','ph','gn','th','qu','gu','rr','ll','mm','nn','tt','pp','ff','ss','cc','dd','bb','gg'].sort((a,b)=>b.length-a.length)
  const COND = {"v":{"_":["v",-0.0],"r":["v",-0.0],"o":["v",-0.0],"e":["v",-0.0],"a":["v",-0.0],"i":["v",-0.0],"u":["v",-0.0]},"r":{"_":["ʁ",0.63],"a":["ʁ",-0.0],"q":["ʁ",-0.0],"s":["ʁ",0.56],"e":["ʁ",0.0],"#":["∅",0.85],"d":["ʁ",-0.0],"o":["ʁ",-0.0],"t":["ʁ",-0.0],"c":["ʁ",-0.0],"i":["ʁ",0.0],"f":["ʁ",-0.0],"v":["ʁ",-0.0],"n":["ʁ",-0.0],"u":["ʁ",-0.0],"m":["ʁ",-0.0],"g":["ʁ",-0.0],"l":["ʁ",-0.0],"b":["ʁ",-0.0],"p":["ʁ",-0.0],"y":["ʁ",-0.0],"h":["ʁ",-0.0]},"ai":{"_":["ɛ",0.27],"m":["ɛ",0.0],"s":["ɛ",0.46],"t":["ɛ",0.09],"r":["ɛ",0.08],"n":["ɛ",0.09],"#":["ɛ",0.12],"e":["ɛ",0.02],"b":["ɛ",0.4],"d":["ɛ",0.46],"g":["ɛ",0.9],"l":["ɛ",0.06]},"m":{"_":["m",0.02],"e":["m",0.0],"o":["m",-0.0],"i":["m",-0.0],"a":["m",-0.0],"u":["m",-0.0],"n":["∅",0.97],"y":["m",-0.0]},"en":{"_":["ɑ̃",0.08],"t":["ɑ̃",0.04],"d":["ɑ̃",0.02],"f":["ɑ̃",0.0],"s":["ɑ̃",0.16],"c":["ɑ̃",0.0],"v":["ɑ̃",0.0],"l":["ɑ̃",-0.0],"n":["ɛ",0.0],"g":["ɑ̃",0.03],"r":["ɑ̃",0.0],"#":["ɛ̃",0.07]},"t":{"_":["t",0.97],"#":["∅",0.18],"o":["t",-0.0],"r":["t",0.0],"u":["t",-0.0],"s":["∅",0.15],"e":["t",0.18],"i":["t",0.0],"a":["t",-0.0],"t":["∅",0.01],"y":["t",-0.0],"c":["t",-0.0]},"p":{"_":["p",0.31],"o":["p",-0.0],"#":["∅",0.05],"r":["p",-0.0],"e":["p",-0.0],"s":["∅",0.83],"i":["p",-0.0],"a":["p",-0.0],"l":["p",-0.0],"t":["p",0.84],"u":["p",-0.0],"n":["p",-0.0],"y":["p",-0.0]},"ou":{"_":["u",0.12],"r":["u",-0.0],"j":["u",-0.0],"p":["u",-0.0],"l":["u",-0.0],"v":["u",-0.0],"d":["u",-0.0],"t":["u",-0.0],"c":["u",-0.0],"h":["w",0.22],"s":["u",-0.0],"i":["u",0.23],"f":["u",-0.0],"e":["w",0.82],"b":["u",-0.0],"a":["w",0.08],"m":["u",-0.0],"z":["u",-0.0],"g":["u",-0.0],"q":["u",-0.0],"x":["u",-0.0],"#":["u",-0.0],"n":["u",-0.0]},"qu":{"_":["k",0.0],"o":["k",-0.0],"e":["k",0.0],"i":["k",0.0],"a":["k",-0.0]},"oi":{"_":["wa",-0.0],"#":["wa",-0.0],"t":["wa",-0.0],"r":["wa",-0.0],"s":["wa",-0.0],"v":["wa",-0.0],"l":["wa",-0.0],"e":["wa",-0.0],"g":["wa",-0.0],"q":["wa",-0.0],"f":["wa",-0.0],"d":["wa",-0.0],"n":["wa",-0.0]},"j":{"_":["ʒ",-0.0],"o":["ʒ",-0.0],"u":["ʒ",-0.0],"e":["ʒ",-0.0],"a":["ʒ",-0.0]},"s":{"_":["∅",1.38],"#":["∅",0.25],"i":["s",1.0],"a":["s",0.88],"e":["s",1.23],"t":["s",0.0],"o":["s",0.54],"q":["s",0.06],"u":["s",0.15],"p":["s",-0.0],"d":["∅",0.04],"f":["s",-0.0],"y":["s",0.14],"m":["z",1.0],"k":["s",-0.0],"b":["s",0.14],"c":["∅",0.2],"n":["s",0.1],"l":["s",0.01]},"b":{"_":["b",0.0],"e":["b",-0.0],"o":["b",-0.0],"i":["b",-0.0],"l":["b",-0.0],"a":["b",-0.0],"u":["b",-0.0],"r":["b",-0.0],"j":["b",-0.0],"d":["b",-0.0],"y":["b",-0.0],"v":["b",-0.0],"s":["b",0.03]},"eau":{"_":["o",-0.0],"c":["o",-0.0],"#":["o",-0.0]},"c":{"_":["k",1.02],"o":["k",-0.0],"t":["k",0.25],"e":["s",0.56],"u":["k",-0.0],"a":["k",-0.0],"r":["k",-0.0],"i":["s",0.16],"l":["k",0.0],"#":["k",0.1],"k":["∅",-0.0],"s":["k",0.93],"y":["s",0.0]},"d":{"_":["d",0.44],"r":["d",-0.0],"e":["d",-0.0],"s":["∅",0.01],"o":["d",-0.0],"i":["d",-0.0],"a":["d",-0.0],"u":["d",-0.0],"#":["∅",0.1],"m":["d",0.03],"v":["d",-0.0],"y":["d",-0.0],"n":["d",-0.0],"j":["d",-0.0]},"e":{"_":["∅",1.93],"#":["∅",0.02],"g":["ə",0.02],"l":["ɛ",1.02],"r":["e",1.46],"s":["∅",1.45],"v":["ə",0.07],"m":["ə",0.32],"z":["e",0.0],"x":["ɛ",0.35],"n":["∅",1.08],"t":["ɛ",1.22],"i":["ɛ",0.47],"c":["ɛ",1.14],"y":["ɛ",0.17],"o":["∅",0.0],"p":["ə",1.14],"j":["ə",-0.0],"d":["ə",0.23],"f":["e",1.1],"q":["ə",0.59],"u":["∅",0.32],"b":["ə",0.42],"a":["∅",0.01]},"on":{"_":["ɔ̃",0.29],"s":["ɔ̃",0.66],"j":["ɔ̃",-0.0],"g":["ɔ̃",-0.0],"f":["ɔ̃",-0.0],"#":["ɔ̃",-0.0],"t":["ɔ̃",-0.0],"d":["ɔ̃",-0.0],"v":["ɔ̃",-0.0],"c":["ɔ̃",-0.0],"b":["ɔ̃",-0.0],"q":["ɔ̃",-0.0],"z":["ɔ̃",-0.0]},"i":{"_":["i",0.69],"e":["j",0.85],"s":["i",0.0],"n":["i",-0.0],"a":["j",0.02],"b":["i",0.0],"v":["i",-0.0],"t":["i",0.0],"r":["i",0.0],"f":["i",-0.0],"c":["i",-0.0],"l":["i",0.02],"z":["i",-0.0],"q":["i",0.01],"d":["i",0.01],"m":["i",-0.0],"g":["i",-0.0],"#":["i",0.06],"o":["j",0.04],"p":["i",-0.0],"u":["j",0.02],"j":["i",0.02],"x":["i",-0.0]},"eu":{"_":["œ",0.94],"r":["œ",0.8],"l":["œ",0.11],"v":["œ",0.25],"x":["ø",-0.0],"s":["ø",0.0],"t":["ø",0.0],"i":["œ",0.0],"b":["œ",-0.0],"g":["œ",0.19],"n":["œ",0.42],"m":["ø",-0.0],"p":["œ",0.94]},"g":{"_":["ʒ",1.21],"a":["ɡ",-0.0],"t":["∅",0.0],"e":["ʒ",0.0],"i":["ʒ",0.0],"o":["ɡ",0.0],"r":["ɡ",-0.0],"l":["ɡ",-0.0],"m":["ɡ",-0.0],"n":["ɡ",0.0],"g":["ɡ",0.01],"s":["ɡ",0.88],"u":["ɡ",0.0],"y":["ʒ",0.02],"h":["ɡ",0.54],"#":["g",0.1]},"a":{"_":["a",-0.0],"r":["a",-0.0],"t":["a",-0.0],"p":["a",-0.0],"m":["a",-0.0],"v":["a",-0.0],"f":["a",-0.0],"c":["a",-0.0],"g":["a",-0.0],"i":["a",-0.0],"b":["a",-0.0],"q":["a",-0.0],"l":["a",-0.0],"s":["a",-0.0],"#":["a",-0.0],"d":["a",-0.0],"n":["a",-0.0],"j":["a",-0.0],"o":["a",-0.0],"z":["a",-0.0],"h":["a",-0.0],"x":["a",-0.0],"y":["a",-0.0],"k":["a",-0.0]},"l":{"_":["l",0.04],"a":["l",0.01],"q":["l",-0.0],"e":["l",0.02],"o":["l",0.02],"i":["l",0.11],"#":["l",0.03],"u":["l",0.0],"d":["l",-0.0],"h":["l",-0.0],"t":["l",0.0],"s":["l",0.46],"v":["l",-0.0],"c":["l",-0.0],"y":["l",-0.0],"m":["l",-0.0],"p":["l",-0.0],"g":["l",-0.0],"f":["l",-0.0]},"tt":{"_":["t",-0.0],"e":["t",-0.0],"a":["t",-0.0],"r":["t",-0.0],"o":["t",-0.0],"i":["t",-0.0],"u":["t",-0.0]},"rr":{"_":["ʁ",-0.0],"a":["ʁ",-0.0],"i":["ʁ",-0.0],"e":["ʁ",-0.0],"o":["ʁ",-0.0],"u":["ʁ",-0.0]},"pp":{"_":["p",-0.0],"e":["p",-0.0],"o":["p",-0.0],"r":["p",-0.0],"a":["p",-0.0],"l":["p",-0.0]},"ll":{"_":["l",-0.0],"e":["l",-0.0],"a":["l",-0.0],"i":["l",-0.0],"o":["l",-0.0],"u":["l",-0.0]},"f":{"_":["f",0.0],"a":["f",0.0],"i":["f",-0.0],"o":["f",-0.0],"e":["f",-0.0],"r":["f",0.01],"u":["f",-0.0],"#":["f",-0.0],"l":["f",0.0],"s":["f",-0.0]},"ill":{"_":["j",1.37],"e":["j",1.14],"i":["il",0.66],"a":["j",1.46],"u":["il",0.24],"o":["j",1.06]},"ail":{"_":["aj",-0.0],"#":["aj",-0.0]},"u":{"_":["y",0.3],"r":["y",0.02],"t":["y",0.0],"s":["y",0.01],"p":["y",0.01],"d":["y",0.01],"#":["y",0.04],"e":["y",1.0],"n":["y",0.05],"c":["y",0.0],"l":["y",0.03],"m":["y",0.0],"g":["y",0.04],"f":["y",-0.0],"b":["y",0.0],"i":["ɥ",0.44],"o":["ɥ",0.59],"q":["y",-0.0],"a":["ɥ",0.87],"z":["y",0.72],"v":["y",-0.0]},"an":{"_":["ɑ̃",-0.0],"t":["ɑ̃",-0.0],"d":["ɑ̃",-0.0],"c":["ɑ̃",-0.0],"g":["ɑ̃",-0.0],"q":["ɑ̃",-0.0],"s":["ɑ̃",-0.0],"v":["ɑ̃",-0.0],"#":["ɑ̃",-0.0],"l":["ɑ̃",-0.0]},"om":{"_":["ɔ̃",-0.0],"b":["ɔ̃",-0.0],"p":["ɔ̃",-0.0],"t":["ɔ̃",-0.0]},"ien":{"_":["jɛ̃",0.63],"#":["jɛ̃",0.0],"s":["jɛ̃",0.0],"n":["jɛ",0.0],"t":["jɛ̃",0.0],"d":["jɛ̃",0.0],"v":["jɛ̃",-0.0]},"im":{"_":["ɛ̃",-0.0],"p":["ɛ̃",-0.0],"b":["ɛ̃",-0.0]},"o":{"_":["o",0.95],"r":["ɔ",0.8],"n":["o",0.97],"c":["o",0.9],"s":["o",0.44],"m":["o",0.31],"l":["o",0.75],"b":["o",0.82],"f":["o",0.21],"g":["o",0.77],"p":["o",0.93],"t":["o",0.73],"j":["o",0.03],"d":["o",0.3],"#":["o",0.17],"v":["o",0.16],"q":["o",0.95],"x":["ɔ",0.02],"a":["o",0.4],"o":["o",0.53]},"ion":{"_":["jɔ̃",-0.0],"#":["jɔ̃",-0.0],"s":["jɔ̃",-0.0]},"h":{"_":["∅",-0.0],"i":["∅",-0.0],"o":["∅",-0.0],"a":["∅",-0.0],"e":["∅",-0.0],"u":["∅",-0.0],"y":["∅",-0.0]},"em":{"_":["ɑ̃",-0.0],"b":["ɑ̃",-0.0],"p":["ɑ̃",-0.0]},"ch":{"_":["ʃ",0.24],"e":["ʃ",0.04],"a":["ʃ",0.05],"o":["ʃ",0.62],"i":["ʃ",0.36],"n":["k",0.15],"r":["k",-0.0],"u":["ʃ",-0.0],"t":["ʃ",0.54]},"ss":{"_":["s",-0.0],"e":["s",-0.0],"i":["s",-0.0],"a":["s",-0.0],"u":["s",-0.0],"o":["s",-0.0],"#":["s",-0.0]},"z":{"_":["∅",0.36],"#":["∅",0.01],"a":["z",-0.0],"i":["z",-0.0],"o":["z",-0.0],"e":["z",0.33],"z":["∅",-0.0]},"nn":{"_":["n",-0.0],"e":["n",-0.0],"a":["n",-0.0],"o":["n",-0.0],"u":["n",-0.0],"i":["n",-0.0]},"ff":{"_":["f",-0.0],"a":["f",-0.0],"i":["f",-0.0],"e":["f",-0.0],"r":["f",-0.0],"o":["f",-0.0],"u":["f",-0.0],"l":["f",-0.0]},"n":{"_":["n",0.8],"u":["n",-0.0],"e":["n",0.33],"t":["∅",0.41],"i":["n",-0.0],"o":["n",-0.0],"a":["n",-0.0],"h":["n",-0.0],"#":["n",0.49],"s":["n",0.2],"y":["n",-0.0]},"x":{"_":["ks",1.47],"c":["ks",-0.0],"a":["ɡz",0.22],"#":["∅",0.04],"p":["ks",-0.0],"e":["ɡz",0.65],"i":["ks",0.99],"t":["ks",-0.0],"u":["ks",0.1],"o":["ɡz",0.88],"y":["ks",0.25],"h":["ɡz",0.03]},"ay":{"_":["ej",0.67],"e":["ej",0.49],"a":["ej",0.9],"o":["ej",0.83]},"ti":{"_":["sj",1.0],"o":["sj",0.0],"l":["ti",-0.0],"m":["ti",-0.0],"n":["ti",-0.0],"c":["ti",-0.0],"t":["ti",-0.0],"r":["ti",-0.0],"q":["ti",-0.0],"f":["ti",-0.0],"e":["sj",0.68],"v":["ti",-0.0],"#":["ti",-0.0],"s":["ti",-0.0],"p":["ti",-0.0],"a":["sj",0.1],"d":["ti",-0.0],"g":["ti",-0.0],"b":["ti",-0.0]},"in":{"_":["ɛ̃",-0.0],"s":["ɛ̃",-0.0],"#":["ɛ̃",-0.0],"f":["ɛ̃",-0.0],"t":["ɛ̃",-0.0],"c":["ɛ̃",-0.0],"v":["ɛ̃",-0.0],"q":["ɛ̃",-0.0],"d":["ɛ̃",-0.0],"j":["ɛ̃",-0.0],"g":["ɛ̃",-0.0]},"ui":{"_":["ɥi",-0.0],"t":["ɥi",-0.0],"r":["ɥi",-0.0],"s":["ɥi",-0.0],"v":["ɥi",-0.0],"c":["ɥi",-0.0],"e":["ɥi",-0.0]},"au":{"_":["o",0.03],"v":["o",0.01],"s":["o",0.01],"d":["o",0.02],"x":["o",0.0],"t":["o",0.03],"f":["o",0.06],"c":["o",0.05],"m":["o",0.01],"p":["o",0.03],"r":["o",0.05],"g":["o",0.06],"b":["o",-0.0]},"oy":{"_":["waj",-0.0],"a":["waj",-0.0],"e":["waj",-0.0],"o":["waj",-0.0]},"mm":{"_":["m",-0.0],"e":["m",-0.0],"a":["m",-0.0],"i":["m",-0.0],"u":["m",-0.0],"o":["m",-0.0]},"ei":{"_":["ɛ",-0.0],"g":["ɛ",-0.0],"n":["ɛ",-0.0]},"gn":{"_":["ɲ",-0.0],"e":["ɲ",-0.0],"i":["ɲ",-0.0],"o":["ɲ",-0.0],"a":["ɲ",-0.0]},"cc":{"_":["k",0.91],"u":["k",-0.0],"i":["ks",-0.0],"a":["k",-0.0],"e":["ks",-0.0],"o":["k",-0.0],"r":["k",-0.0],"l":["k",-0.0]},"ua":{"_":["ɥa",0.54],"t":["ɥa",0.31],"d":["ɥa",0.82],"r":["wa",0.01]},"eil":{"_":["ɛj",-0.0],"#":["ɛj",-0.0],"s":["ɛj",-0.0]},"y":{"_":["i",0.74],"e":["j",0.11],"s":["i",0.04],"c":["i",0.12],"p":["i",-0.0],"n":["i",-0.0],"m":["i",-0.0],"r":["i",-0.0],"o":["j",0.08],"#":["i",0.04],"t":["i",-0.0],"l":["i",-0.0],"a":["j",0.24],"d":["i",-0.0]},"ain":{"_":["ɛ̃",-0.0],"#":["ɛ̃",-0.0],"c":["ɛ̃",-0.0],"s":["ɛ̃",-0.0],"d":["ɛ̃",-0.0],"t":["ɛ̃",-0.0],"q":["ɛ̃",-0.0]},"sc":{"_":["sk",1.0],"u":["sk",-0.0],"e":["s",-0.0],"i":["s",-0.0],"a":["sk",-0.0],"l":["sk",-0.0],"r":["sk",-0.0],"o":["sk",-0.0]},"q":{"_":["k",-0.0],"u":["k",-0.0]},"ue":{"_":["ə",0.16],"#":["ə",0.42],"m":["ə",-0.0],"r":["ə",0.0],"f":["ə",-0.0],"l":["ə",0.26],"t":["ə",0.02]},"oin":{"_":["wɛ̃",-0.0],"d":["wɛ̃",-0.0],"s":["wɛ̃",-0.0],"t":["wɛ̃",-0.0],"c":["wɛ̃",-0.0]},"am":{"_":["ɑ̃",-0.0],"p":["ɑ̃",-0.0],"b":["ɑ̃",-0.0]},"ein":{"_":["ɛ̃",-0.0],"d":["ɛ̃",-0.0],"t":["ɛ̃",-0.0]},"eaux":{"_":["o",-0.0],"#":["o",-0.0]},"ean":{"_":["ɑ̃",-0.0],"c":["ɑ̃",-0.0],"t":["ɑ̃",-0.0]},"un":{"_":["œ̃",0.29],"t":["œ̃",0.0]},"ueil":{"_":["œj",-0.0],"#":["œj",-0.0],"l":["œj",-0.0]},"euil":{"_":["œj",-0.0],"#":["œj",-0.0]},"gu":{"_":["ɡ",0.84],"i":["ɡ",0.77],"e":["ɡ",0.0],"m":["ɡy",-0.0],"r":["ɡy",-0.0],"l":["ɡy",-0.0],"a":["ɡ",0.01]},"um":{"_":["ɔm",0.42],"#":["ɔm",0.02]},"ym":{"_":["ɛ̃",-0.0],"b":["ɛ̃",-0.0],"p":["ɛ̃",-0.0]},"yn":{"_":["ɛ̃",-0.0],"c":["ɛ̃",-0.0],"d":["ɛ̃",-0.0]},"ph":{"_":["f",-0.0],"y":["f",-0.0],"e":["f",-0.0],"o":["f",-0.0],"a":["f",-0.0],"i":["f",-0.0]},"k":{"_":["k",-0.0],"e":["k",-0.0],"t":["k",-0.0],"i":["k",-0.0],"a":["k",-0.0],"p":["k",-0.0],"#":["k",-0.0],"l":["k",-0.0]},"th":{"_":["t",-0.0],"e":["t",-0.0],"i":["t",-0.0],"o":["t",-0.0],"m":["t",-0.0],"r":["t",-0.0]},"dd":{"_":["d",-0.0],"i":["d",-0.0]},"sh":{"_":["ʃ",-0.0],"a":["ʃ",-0.0],"e":["ʃ",-0.0]},"oui":{"_":["wi",-0.0],"n":["wi",-0.0]},"w":{"_":["w",0.19]},"gg":{"_":["ɡ",-0.0],"r":["ɡ",-0.0]},"cqu":{"_":["k",-0.0],"i":["k",-0.0]},"bb":{"_":["b",-0.0]},"aim":{"_":["ɛ̃",-0.0]}}
  const EPRON = new Set(["ces","des","les","mes","pes","ses","tes"]);   // e+s FINAL PRONONCÉ /e/ (liste fermée, vérité-terrain)
  const CFIN_MUET = new Set(["accroc","ajonc","antitabac","banc","blanc","broc","caoutchouc","clerc","convainc","croc","entrelac","escroc","estomac","flanc","franc","jonc","lanc","marc","porc","ranc","tabac","tronc"]);   // « c » final MUET (liste fermée, vérité-terrain)
  const GFIN_MUET = new Set(["asag","bourg","coing","config","faubourg","furlong","hareng","joug","long","oblong","oing","outang","outing","parpaing","poing","rang","sang","schampooing","seing","shampoing","shampooing","tripang","étang"]);   // « g » final MUET (liste fermée, vérité-terrain)
  const ENTAMBIG = new Set(["consent","coprésident","divergent","détergent","expédient","ferment","purulent","ressent","résident","résilient","strident","talent","truculent","équivalent","évident"]);   // -ent HOMOGRAPHES : nom/adjectif ET 3e pers. pluriel — seule la POS trancherait, en contexte
  const RFIN = new Set(["acer","after","alter","amer","anticancer","aster","beeper","ber","bestseller","biker","bipper","blazer","blister","blockbuster","boer","bookmaker","boomer","bootlegger","bulldozer","bunker","burger","cancer","cascher","casher","cathéter","charter","cheerleader","cheeseburger","cher","chester","clipper","clubber","cluster","confer","coroner","crooner","cuiller","cutter","cyber","dealer","der","dogger","dragster","drifter","driver","drummer","dumper","enfer","ether","eyeliner","fer","fier","follower","freezer","führer","gamer","gangster","getter","geyser","gyrolaser","hacker","hamburger","hamster","handler","hier","highlander","hiver","holster","hunter","hyper","imper","inter","joker","jumper","junker","karcher","kascher","kasher","keylogger","khmer","kipper","laser","leader","liber","lieder","looser","magister","marker","maser","masséter","master","mer","moder","outremer","outsider","pacemaker","panzer","partner","pater","picker","pier","placer","pointer","poker","polyéther","popper","pullover","quaker","raider","raver","retriever","revolver","rocker","roller","rooter","rottweiler","rover","runner","révolver","scanner","scooter","scraper","setter","shiner","sitter","skater","slasher","speaker","spencer","sphincter","spinnaker","sprinter","squatter","stathouder","steamer","sticker","streamer","subwoofer","super","supertanker","sweater","taser","teaser","tender","ter","thaler","toner","trimmer","truther","turnover","tweeter","ulster","vener","ver","wafer","water","webmaster","winchester","wiper","éther"]);   // -er au r PRONONCÉ (liste fermée, vérité-terrain)
  const ENTSIL = new Set(["abandonnent","abattent","aboient","absorbent","abusent","acceptent","accepteraient","accompagnent","accordent","accrochent","accueillent","accumulent","accusent","adaptent","admirent","adoraient","adorent","adoreraient","advient","affectent","affirment","affrontent","agissent","agitent","aidaient","aideraient","aillent","aimaient","aimeraient","ajoutent","allaient","allument","amusaient","amusent","annoncent","annulent","apparaissent","appartenaient","appartiennent","appartient","appelaient","appellent","applaudissent","appliquent","apportent","apprenaient","apprennent","approchent","approuvent","arrachent","arrangent","arrivaient","arrivent","arriveraient","aspirent","assoient","assurent","attachent","attaquaient","attaquent","atteignent","attendaient","attendent","atterrissent","attirent","attrapent","augmentent","auraient","autorisent","avancent","baisent","baissent","baladent","balancent","battaient","battent","blessent","bloquent","boivent","bombardent","bossent","bouffent","bougent","bousculent","brillent","brisent","buvaient","cachaient","cachent","calment","cassent","causent","cessent","changent","chantaient","chantent","chargent","chassent","cherchaient","cherchent","choisissent","chutent","circulent","claquent","collent","combattent","commandent","commencent","commettent","communiquent","compliquent","complotent","comportent","comprenaient","comprendraient","comprennent","comptaient","comptent","concentrent","concernent","concordent","conduisent","confirment","confondent","connaissaient","connaissent","consent","consomment","constituent","construisent","contenaient","contentent","contiennent","contient","continuaient","continuent","conviennent","correspondaient","correspondent","couchaient","couchent","coulent","coupent","couraient","courent","couvrent","crachent","craignaient","craignent","craquent","creusent","criaient","crissent","croient","croiraient","croisent","croyaient","cuisinent","dansaient","dansent","demandaient","demandent","demeurent","descendent","devaient","devenaient","deviennent","devient","devinrent","devraient","diffusent","diminuent","diraient","dirigeaient","dirigent","disaient","discutent","disparaissaient","disparaissent","disposent","disputaient","disputent","distribuent","divorcent","doivent","dominent","donnaient","donnent","donneraient","dormaient","dorment","doutent","dressent","droguent","effacent","effondrent","effraient","embarquent","embauchent","embrassent","emmenaient","emmerdent","emparent","empirent","emploient","emportent","encerclent","encouragent","endorment","enferment","enfoncent","enfuient","engagent","ennuient","enregistrent","enseignent","entendaient","entendent","enterrent","entourent","entraient","entrent","entretient","entretuent","envahissent","enverraient","envoient","envolent","envoyaient","essaient","essayaient","essayent","estiment","examinent","excitent","exigent","existaient","existent","expliquent","exploitent","explosent","expriment","fabriquent","faisaient","fassent","fatiguent","feraient","ferment","fichent","figurent","filment","financent","finissent","fleurissent","flottent","foncent","fonctionnaient","fonctionnent","fondent","forcent","formaient","forment","fouillent","fournissent","foutaient","foutent","frappent","gagnent","gardaient","gardent","glissent","grandissent","grimpent","grouillent","guident","habillent","habitaient","habitent","hantent","hurlent","ignoraient","ignorent","imaginent","impliquent","importent","imposent","incluent","indiquent","insistent","inspirent","installent","interdisent","interrogent","intervient","inventent","invitent","iraient","jetaient","jettent","jouaient","laissaient","laissent","laisseraient","lancent","livrent","luttent","maintiennent","maintient","mangeaient","mangent","manifestent","manipulent","manquaient","manquent","marchaient","marchent","marient","marquent","menacent","menaient","mentent","mesurent","mettaient","mettent","mettraient","meurent","mijotent","montaient","montent","montraient","montrent","moquaient","moquent","mordent","mouraient","mourraient","multiplient","naissent","nettoient","nomment","nourrissent","obligent","observent","obtiennent","obtient","occupaient","occupent","offraient","offrent","opposent","organisent","oublient","ouvrent","paieraient","paniquent","paraissent","parcourent","pardonnent","parlaient","parlent","partageaient","partagent","partaient","partent","participent","partirent","parviennent","parvient","passaient","passent","passeraient","patrouillent","payaient","pendent","pensaient","pensent","penseraient","perdent","permettent","peuvent","piquent","pissent","placent","plaignent","plaisantent","plaisent","plantent","pleuraient","pleurent","plongent","pointent","pondent","portaient","portent","posaient","pourchassent","pourraient","pourrissent","poursuivaient","poursuivent","poussaient","poussent","pouvaient","pratiquent","prenaient","prendraient","prennent","prirent","produisent","profitent","progressent","promettent","proposent","prouvent","provenaient","proviennent","provient","provoquent","puissent","quittent","racontent","raffolent","ralentissent","ramassent","rampent","rappellent","rapportent","rapprochent","rassemblent","rattrapent","recherchaient","recherchent","recommencent","reconnaissent","redeviennent","redevient","refusaient","refusent","regardaient","regardent","rejettent","rejoignent","relient","remarquent","remercient","remettent","remontent","remplacent","remplissent","rencontrent","rendaient","rendent","renoncent","rentraient","rentrent","renvoient","repartent","reposent","repoussent","reprennent","reproduisent","respectent","respirent","ressemblaient","ressemblent","ressent","ressentent","ressortent","restaient","restent","retiennent","retient","retirent","retournent","retrouvent","revenaient","reviendraient","reviennent","revient","riaient","rigolent","risquent","roulent","ruinent","sachent","saignent","saluent","sauraient","sautent","sauvent","savaient","semblaient","semblent","sentaient","sentent","seraient","serrent","servaient","servent","sifflent","signalent","signent","signifient","soignent","sonnent","sortaient","sortent","soucient","souffrent","souhaitent","sourient","soutiennent","soutient","souviennent","souvient","subissent","suffiraient","suffisent","suicident","suivaient","suivent","suivirent","supportent","surgissent","surveillaient","surveillent","survient","survivent","taisent","tenaient","tendent","tentaient","tentent","terminent","testent","tiennent","tiraient","tombaient","tombent","torturent","touchent","tournaient","tournent","trahissent","traitaient","traitent","transforment","transmettent","transportent","traquent","travaillaient","travaillent","traversent","tremblaient","tremblent","trompent","trouvaient","trouvent","trouveraient","tuaient","tueraient","unissent","utilisaient","utilisent","valaient","veillent","venaient","vendaient","vendent","verraient","veuillent","veulent","vieillissent","viendraient","viennent","vinrent","vivaient","volaient","voudraient","voulaient","voyagent","voyaient"])
  function g2p(word){
    const w=word.toLowerCase().replace(/[^a-zàâäéèêëîïôöùûüÿç]/g,'')
    const steps=[]; let i=0
    while(i<w.length){
      let g=null
      for(const cand of SEG){
        if(!w.startsWith(cand,i)) continue
        const after=i+cand.length<w.length?w[i+cand.length]:'#'
        if(NASAL.has(cand)&&(VOW.includes(after)||after==='n'||after==='m')) continue
        g=cand; break
      }
      if(!g) g=w[i]
      const prev = i>0 ? w[i-1] : '#'
      const nxt=i+g.length<w.length?w[i+g.length]:'#'
      let ph='?',h=0
      if(DBL.has(g)){ const t=COND[g]; if(t){const e=t[nxt]||t['_']; ph=e[0]; h=e[1]} else {const e=(COND[g[0]]&&COND[g[0]]['_'])||[g[0],0]; ph=(e[0]&&e[0]!=='∅')?e[0]:g[0]; h=0} }   // bug DBL→∅ corrigé (ss/gg/zz) : COND[g] d'abord (l'entrée du digramme est correcte), repli anti-∅ — miroir dictee/decompose.py
      else { const t=COND[g]; if(t){const e=t[nxt]||t['_']; ph=e[0]; h=e[1]} }
      // ── contexte GAUCHE (bilatéral) : règles déterministes connues ──
      if(g==='s' && VOW.includes(prev) && VOW.includes(nxt)){ ph='z'; h=0.10 }      // s intervocalique → /z/  (maison, rose)
      else if(g==='x' && VOW.includes(prev) && VOW.includes(nxt)){ ph='ɡz'; h=0.15 }// x intervocalique → /gz/ (examen)
      // ⭐ 25/09/2026 — LE « R » FINAL N EST PAS MUET (rapport de Rem : « pour, jour, sur, bonjour, mer :
      // ils sont pas muets ces r »). La table COND est indexée sur le SUIVANT : en fin de mot elle ne voit
      // que « # » et tranchait MUET avec h=0,85 — son hésitation la plus haute. Ce « # » mélange les
      // infinitifs en -er (muets) et tout le reste (prononcé). La table APPRISE avait refusé de trancher :
      // g2p_corrections.json a une entrée « r+suivant » pour 29 lettres et AUCUNE pour « # » (sous le seuil
      // de pureté). La donnée disait « je ne sais pas » ; la table de base répondait quand même.
      // Mesuré sur les 7 263 mots du lexique finissant par r : 72,9 % → 97,8 % justes, UN seul mot
      // « cassé » (désassortir, dont le gold porte la prononciation de « désassorti » — c est le gold
      // qui est fautif). Miroir exact dans dictee/decompose.py.
      else if(g==='r' && nxt==='#' && prev!=='e'){ ph='ʁ'; h=0.05 }
      steps.push({g,ph,h:Math.max(0,h)}); i+=g.length
    }
    /* ⭐ 25/09/2026 — LE « -ent » DES VERBES : la table qui le sait était DÉJÀ là.
       ⚠️ Le commentaire précédent disait « la POS lève l ambiguïté ». C était FAUX : aucune POS n intervenait,
       le code lisait une liste figée de 582 mots. Le tagger existe (58 appels dans l app) mais ne peut pas
       servir ici — `g2p(mot)` reçoit UN mot, jamais la phrase. Rem, 25/09 : « vérifie ce qui existe,
       parce qu ils mettent que ça marche ».
       Ce qui existe : `vdc-lex.json`, déjà embarqué ici ET dans l extension, porte 66 146 formes
       conjuguées (CONJ_F) et 5 948 verbes (CONJ_C). Une forme de 3e personne du PLURIEL s y lit
       directement. Mesuré sur les 8 137 mots dont le -ent est muet au gold : 7,0 % avec ENTSIL seul,
       95,8 % avec la table — ZÉRO octet de donnée ajouté, on lit ce qui était déjà en mémoire.
       Les 13 exclus sont de vrais homographes (ferment, résident, évident, divergent, talent…) : nom ou
       adjectif d un côté, « ils … » de l autre. Seule la POS les tranche EN CONTEXTE, donc pas ici :
       on les laisse au défaut « prononcé », conforme au gold.
       ⚠️ Garde de repli : hors de l app (extension/assets/g2p.js est autonome), CONJ_F peut ne pas
       exister — on retombe alors sur ENTSIL, jamais sur une erreur. */
    /* index PARESSEUX des 3e personnes du pluriel : CONJ_F est une projection INCOMPLÈTE de CONJ_C
       (mesuré : 69,2 % des -ent muets par CONJ_F seul, 95,8 % en lisant aussi l arbre). On construit
       l index une fois, à la première question, depuis les tables déjà chargées. */
    let _3P = null;
    function _build3P(){
      _3P = new Set();
      try{
        const _C = (typeof CONJ_C!=='undefined' && CONJ_C) ||
          (typeof self!=='undefined' && self.__OMEGA_CJ && self.__OMEGA_CJ.c) || null;
        if(_C) for(const lem in _C){
          const modes = _C[lem]; if(!modes) continue;
          for(const mo in modes){ const f = modes[mo] && modes[mo]['3p'];
            if(typeof f === 'string') _3P.add(f); else if(Array.isArray(f)) f.forEach(x=>_3P.add(x)); }
        }
      }catch(e){}
      return _3P;
    }
    function _entVerbe(m){
      if(ENTAMBIG.has(m)) return false;
      try{
        /* l app : CONJ_F est global ici. Hors de l app (extension), dys-core publie self.__OMEGA_CJ. */
        const _F = (typeof CONJ_F!=='undefined' && CONJ_F) ||
          (typeof self!=='undefined' && self.__OMEGA_CJ && self.__OMEGA_CJ.f) || null;
        if(_F){ const e=_F[m];
          if(e && String(e).split('|').some(t=>t.endsWith(';3;p'))) return true; }
        if((_3P || _build3P()).has(m)) return true;
      }catch(e){}
      return false;
    }
    // ⚠️ ENTAMBIG PRIME sur ENTSIL : la liste faite main contenait déjà « ferment », que le gold donne
    // prononcé (le ferment, un nom). Une liste écrite à la main ne bat pas une mesure.
    if(!ENTAMBIG.has(w) && (ENTSIL.has(w) || _entVerbe(w)) && w.endsWith('ent')){
      for(let k=steps.length-1;k>=0;k--){ if(steps[k].g==='en'){ steps[k].ph='∅'; steps[k].h=0.02; break } }
    }
    /* ⭐ 25/09/2026 — les -er dont le r SE PRONONCE. Liste FERMÉE de 160 mots relevés un par un dans la
       vérité-terrain phonétique (amer, cher, enfer, fer, fier, hier, hiver, mer, ver… et les emprunts :
       blazer, burger, dealer…). Fermée par construction : elle ne peut rien casser d autre qu elle-même.
       Un -er hors liste garde le défaut « muet », juste dans 97 % des cas : on ne remplace pas une erreur
       systématique par une autre. Avec elle : 100 % sur les 7 263 mots mesurés. */
    if(RFIN.has(w)){
      for(let k=steps.length-1;k>=0;k--){ if(steps[k].g==='r'){ steps[k].ph='ʁ'; steps[k].h=0.05; break } }
    }
    /* ⭐ 26/09/2026 — « c » et « g » finaux : le défaut était à l ENVERS. Mesuré par alignement
       contre la vérité-terrain : 141 des 163 « c » finaux se prononcent (la table disait muet pour
       tous : 87 % faux), 116 des 139 « g » (77 % faux). Défaut renversé dans COND ; les muets
       restent en liste FERMÉE, relevée dans le gold. */
    if(CFIN_MUET.has(w) || GFIN_MUET.has(w)){
      const _d = steps[steps.length-1];
      if(_d && (_d.g==='c' || _d.g==='g')){ _d.ph='∅'; _d.h=0.05; }
    }
    /* ⭐ 25/09/2026 — le « e » de « les » n est pas muet. Même forme que le « r » final :
       COND['e']['s'] tranche MUET avec h = 1,45, la deuxième hésitation la plus haute de la table.
       C est juste pour l immense majorité (petites, portes, chantes) et faux pour une poignée de
       monosyllabes — SEPT, relevés dans la vérité-terrain. Six sont des déterminants présents dans
       presque toutes les phrases : les colorer en muet serait se tromper sur les mots les plus
       courants qu on affiche. Liste fermée : elle ne peut rien casser d autre qu elle-même. */
    if(EPRON.has(w)){
      for(let k=0;k<steps.length;k++){ if(steps[k].g==='e'){ steps[k].ph='e'; steps[k].h=0.05; break } }
    }
    return steps
  }
  function phonScore(word) {
    const s = g2p(word); if (!s.length) return 0;
    let h = 0; for (let k = 0; k < s.length; k++) h += s[k].h;
    return -h / s.length;
  }
  let _LP = null;
  function buildOrtho() {
    const LP = [], C = [];
    for (let i = 0; i < 26; i++) { LP.push(new Float64Array(26)); C.push(new Float64Array(26)); }
    if (typeof OMEGA_LEX4 === 'object' && OMEGA_LEX4 && OMEGA_LEX4.words) {
      const W = OMEGA_LEX4.words;
      for (let k = 0; k < W.length; k++) {
        const m = W[k] && W[k].m; if (typeof m !== 'string') continue;
        const wt = (typeof W[k].f === 'number' && W[k].f > 0) ? W[k].f : 0.001;
        for (let p = 0; p + 1 < m.length; p++) {
          const a = m.charCodeAt(p) - 65, b = m.charCodeAt(p + 1) - 65;
          if (a >= 0 && a < 26 && b >= 0 && b < 26) C[a][b] += wt;
        }
      }
    }
    for (let i = 0; i < 26; i++) {
      let row = 0; for (let j = 0; j < 26; j++) row += C[i][j];
      const denom = row + 26;
      for (let j = 0; j < 26; j++) LP[i][j] = Math.log((C[i][j] + 1) / denom);
    }
    return LP;
  }
  function orthoScore(word) {
    if (!_LP) _LP = buildOrtho();
    if (word.length < 2) return 0;
    let s = 0, n = 0;
    for (let p = 0; p + 1 < word.length; p++) {
      const a = word.charCodeAt(p) - 65, b = word.charCodeAt(p + 1) - 65;
      if (a >= 0 && a < 26 && b >= 0 && b < 26) { s += _LP[a][b]; n++; }
    }
    return n > 0 ? s / n : 0;
  }
  function declare(revLetters, revMask, tried, wlen, conf, wO, wP) {
    if (typeof OMEGA_LEX4 !== 'object' || !OMEGA_LEX4 || !OMEGA_LEX4.words) return null;
    const len_idx = OMEGA_LEX4.len_index; if (!len_idx || !len_idx[wlen]) return null;
    const ids = len_idx[wlen], words = OMEGA_LEX4.words;
    const cands = []; let logmax = -Infinity;
    for (let i = 0; i < ids.length; i++) {
      const w = words[ids[i]]; if (!w || !w.m || w.m.length !== wlen) continue;
      const m = w.m; let ok = true;
      for (let p = 0; p < wlen; p++) {
        if (revMask[p]) { if (m.charAt(p) !== revLetters[p]) { ok = false; break; } }
        else { const li = m.charCodeAt(p) - 65; if (li >= 0 && li < 26 && tried[li]) { ok = false; break; } }
      }
      if (!ok) continue;
      const f = (typeof w.f === 'number' && w.f > 0) ? w.f : 0.001;
      const ls = Math.log(f) + wO * orthoScore(m) + wP * phonScore(m);
      cands.push({ m: m, ls: ls }); if (ls > logmax) logmax = ls;
    }
    if (!cands.length) return null;
    let Z = 0, bestP = -1, bestM = null;
    for (let i = 0; i < cands.length; i++) { const e = Math.exp(cands[i].ls - logmax); cands[i].e = e; Z += e; }
    for (let i = 0; i < cands.length; i++) { const post = cands[i].e / Z; if (post > bestP) { bestP = post; bestM = cands[i].m; } }
    return (bestP >= conf) ? { word: bestM, post: bestP, n: cands.length } : { word: null, post: bestP, n: cands.length };
  }
  function selfTest() {
    const a = g2p('POURQUOI'); const okG = Array.isArray(a) && a.length > 0;
    const okO = isFinite(orthoScore('MAISON'));
    let okD = true; try { declare([], new Array(7).fill(false), new Array(26).fill(false), 7, 0.9, 0.5, 0.25); } catch (e) { okD = false; }
    return okG && okO && okD;
  }
  return { g2p: g2p, phonScore: phonScore, orthoScore: orthoScore, declare: declare, selfTest: selfTest };
})();
