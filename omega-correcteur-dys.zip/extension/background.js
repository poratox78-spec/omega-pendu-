// background.js — service worker (MV3) : menu contextuel « corriger ce mot » au CLIC DROIT sur un champ éditable.
// Le content script calcule la correction du mot sous le curseur et pousse le libellé ; ce SW ne fait que
// (re)créer l'entrée de menu, la mettre à jour, et renvoyer le clic au content script qui applique.
function createMenu() {
  try {
    chrome.contextMenus.removeAll(function () {
      void chrome.runtime.lastError;
      chrome.contextMenus.create({ id: 'omdys-fix', title: '🩹 Correcteur dys', contexts: ['editable'] }, function () { void chrome.runtime.lastError; });
    });
  } catch (e) {}
}
chrome.runtime.onInstalled.addListener(createMenu);
chrome.runtime.onStartup.addListener(createMenu);

// clic sur l'icône de l'extension → ouvre le PANNEAU LATÉRAL (le correcteur "surface propre", F12-style)
try { chrome.sidePanel && chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(function () {}); } catch (e) {}

/* ⭐ FERMER LE PANNEAU COUPE LA BULLE (09/09/2026, décision de Rem : « un utilisateur qui ne
   comprend pas d'où ça vient désinstalle »). Un side panel MV3 n'a pas d'événement de fermeture
   fiable — `unload`/`pagehide` n'y sont pas garantis. Le mécanisme prévu par Chrome est le PORT :
   le panneau en ouvre un ici, et Chrome le déconnecte quand la page du panneau disparaît, quelle
   qu'en soit la cause. On éteint alors `enabled` ; `content.js` le voit par `storage.onChanged`,
   le fil qui existe déjà. Rouvrir le panneau ne rallume PAS la bulle : elle est décochée par
   défaut depuis 07/2026, l'utilisateur la recoche s'il la veut. */
/* ⭐ 11/10/2026 — la POLICE et les COULEURS des pages consultées suivent aussi le panneau (rapport de Rem : l'extension fermée, nos
   polices restaient sur les sites). Clé omPanneau : vraie tant qu'au moins un panneau est ouvert (un par fenêtre), éteinte au
   dernier qui se ferme. Les cases « Aa OMEGA Dys » et « 🎨 Couleurs » gardent leur choix : rouvrir le panneau remet tout. */
var _nPanneaux = 0;
try {
  chrome.runtime.onConnect.addListener(function (port) {
    if (!port || port.name !== 'omdys-panneau') return;
    _nPanneaux++;
    try { chrome.storage.local.set({ omPanneau: true }); } catch (e) {}
    port.onMessage.addListener(function () {});   // le battement du panneau : il suffit qu'il arrive
    port.onDisconnect.addListener(function () {
      void chrome.runtime.lastError;
      _nPanneaux = Math.max(0, _nPanneaux - 1);
      try { chrome.storage.local.set(_nPanneaux ? { enabled: false } : { enabled: false, omPanneau: false }); } catch (e) {}
    });
  });
} catch (e) {}

/* ⭐⭐ LE PORT NE SUFFIT PAS (mesuré le 10/09/2026, Chrome réel) : un service worker MV3 est terminé
   après ~30 s sans événement, et un port SILENCIEUX ne le garde pas en vie. Panneau ouvert 2 s puis
   fermé → bulle éteinte ; ouvert 45 s sans frappe puis fermé → la bulle RESTAIT ALLUMÉE, le SW étant
   mort avant la fermeture. Le cas réel est celui-là : on tape, on s'arrête, on ferme plus tard.
   Réparation : chaque message « omdys-mirror » de la page (une salve de frappe) RÉVEILLE ce SW ; il
   demande alors à Chrome si un document du panneau existe encore. Aucun → `enabled` s'éteint, et la
   réponse dit « panneau: false » pour que content.js n'affiche rien en attendant storage.onChanged.
   Chrome < 116 (pas de getContexts) → réponse « null », on ne touche à rien. Le port reste : il coupe
   SANS DÉLAI tant que le SW est vivant. */
var URL_PANNEAU = chrome.runtime.getURL('sidepanel.html');
function panneauOuvert(cb) {
  try {
    if (!chrome.runtime.getContexts) return cb(null);
    chrome.runtime.getContexts({ documentUrls: [URL_PANNEAU] }).then(function (c) { cb(!!(c && c.length)); }, function () { cb(null); });
  } catch (e) { cb(null); }
}
/* au RÉVEIL du service worker (il a pu dormir pendant que le panneau se fermait) et quand une page qui s'habille le demande
   (« omdys-panneau? ») : aucun document du panneau → omPanneau s'éteint. Chrome < 116 (pas de getContexts) : on ne touche à rien. */
function _verifPanneau(cb) {
  panneauOuvert(function (ouvert) {
    if (ouvert === false) { try { chrome.storage.local.set({ omPanneau: false }); } catch (e) {} }
    if (cb) cb(ouvert);
  });
}
_verifPanneau();
chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (!msg || msg.type !== 'omdys-panneau?') return;
  _verifPanneau(function (ouvert) { try { sendResponse({ panneau: ouvert }); } catch (e) {} });
  return true;   // réponse asynchrone
});
chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (!msg || msg.type !== 'omdys-mirror') return;
  panneauOuvert(function (ouvert) {
    if (ouvert === false) {
      try { chrome.storage.local.get(['enabled'], function (o) { if (o && o.enabled === true) chrome.storage.local.set({ enabled: false }); }); } catch (e) {}
    }
    try { sendResponse({ panneau: ouvert }); } catch (e) {}
  });
  return true;   // réponse asynchrone
});

// le content script (contextmenu) pousse le libellé du mot sous le curseur (« 🩹 « von » → « vont » ») + activé/grisé
chrome.runtime.onMessage.addListener(function (msg) {
  if (msg && msg.type === 'omdys-menu') {
    try { chrome.contextMenus.update('omdys-fix', { title: msg.title || '🩹 Correcteur dys', enabled: msg.enabled !== false }); } catch (e) {}
  }
});

// clic sur l'entrée → renvoie au content script de l'onglet, qui applique la correction mémorisée
chrome.contextMenus.onClicked.addListener(function (info, tab) {
  if (info.menuItemId === 'omdys-fix' && tab && tab.id != null) {
    chrome.tabs.sendMessage(tab.id, { type: 'omdys-apply-rc' }, function () { void chrome.runtime.lastError; });
  }
});

// MIROIR FIDÈLE (Rem, 2026-08-21) : autre onglet activé ou navigation de l'onglet actif → le panneau (s'il est en
// miroir) se vide : il n'affirme jamais un texte que la page n'a plus. Pas de permission « tabs » requise
// (onActivated/onUpdated ne livrent ici que des identifiants et un statut).
function preventPanneau() { try { chrome.runtime.sendMessage({ type: 'omdys-tab' }, function () { void chrome.runtime.lastError; }); } catch (e) {} }
try { chrome.tabs.onActivated.addListener(function () { preventPanneau(); }); } catch (e) {}
try { chrome.tabs.onUpdated.addListener(function (id, ch, tab) { if (ch && ch.status === 'loading' && tab && tab.active) preventPanneau(); }); } catch (e) {}

/* ⭐ « CETTE PAGE EST-ELLE BRANCHÉE ? » (19/09/2026). Le panneau ne peut pas le savoir seul : il n'a
   aucun lien direct avec l'onglet. On demande ici, et on répond par un BOOLÉEN, jamais par un message
   tout fait — le texte montré à un lecteur dys se décide dans le panneau, pas dans le service worker.
   ⚠️ Aucune permission nouvelle : `tabs.query` sans la permission « tabs » rend bien l'identifiant
   (l'URL est vide, on ne s'en sert pas), et `tabs.sendMessage` distingue déjà les deux états. */
chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (!msg || msg.type !== 'omdys-branche?') return;
  try {
    chrome.tabs.query({ active: true, lastFocusedWindow: true }, function (ts) {
      var t = ts && ts[0];
      if (!t || t.id == null) { try { sendResponse({ branche: null }); } catch (e) {} return; }
      chrome.tabs.sendMessage(t.id, { type: 'omdys-ping' }, function (rep) {
        var e = chrome.runtime.lastError;   // « Receiving end does not exist » = aucun script de contenu
        // ⭐ 10/10/2026 — + « le chargement de la page est-il terminé ? » (`status`, lisible SANS la permission « tabs ») : pendant le
        // chargement, « pas de script » ne veut rien dire — il arrive à la fin (document_idle), pas avant.
        try { sendResponse({ branche: !e && !!(rep && rep.branche), charge: t.status === 'complete' }); } catch (x) {}
      });
    });
  } catch (e) { try { sendResponse({ branche: null }); } catch (x) {} }
  return true;   // réponse asynchrone
});

// le panneau demande de recharger l'onglet actif. `tabs.reload` ne réclame AUCUNE permission (mesuré).
chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (!msg || msg.type !== 'omdys-recharge') return;
  try {
    chrome.tabs.query({ active: true, lastFocusedWindow: true }, function (ts) {
      var t = ts && ts[0];
      if (t && t.id != null) chrome.tabs.reload(t.id, {}, function () { void chrome.runtime.lastError; });
      try { sendResponse({ ok: true }); } catch (e) {}
    });
  } catch (e) { try { sendResponse({ ok: false }); } catch (x) {} }
  return true;
});
